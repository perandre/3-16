
Views Slideshow: Cycle
============================

The original default slideshow mode for Views Slideshow.


Description
===========

The Views Slideshow: Cycle module adds a Views display for showing rows as items
in a jQuery slideshow. Rows could be single images, full nodes, fields, or
whatever else that Views can display.

Controls can be added to control the slideshow. And it also has the ability to
allow modules to create different pagers for it.
